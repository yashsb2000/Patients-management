<html>
<body>
<h1> Good for you ! Take care and stay healthy. <br>
 Do not hesitate to tell us if anyone in your family falls ill in the future. <br>
 Remember, in any case, precaution is better than cure. Kindly follow the precautions mentioned below
 amd protect yourself and your family from the novel covid-19<br><br></h1>
<h2>Precautions :</h2> 


<h3>
<br>
->Wash hands frequently with soap or an alcohol based rub for frequently and each time for atleast 20 seconds<br>
->Avoid crowded places and strictly maintain social distancing <br>
-> Make the affected person wear a mask<br>
-> Make the person wash hands frequently and avoid touching surfaces<br>
-> Practice respiratory hygiene<br>
</h3>
</body>
</html>