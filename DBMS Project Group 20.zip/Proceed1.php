<html>
<body>
<h1>There is a high chance that the person is suffering from Covid-19  
<br>Do not panic ! Just take the following precautions </h1>
<p> Precautions : <br><br><br>
->Wash hands frequently with soap or an alcohol based rub for frequently and each time for atleast 20 seconds<br>
->Avoid crowded places and strictly maintain social distancing <br>
-> Make the affected person wear a mask<br>
-> Make the person wash hands frequently and avoid touching surfaces<br>
-> Practice respiratory hygiene<br>
</p>
<h2> You may expect the check-up of your sick family member soon ..... </h2>
</body>
</html>