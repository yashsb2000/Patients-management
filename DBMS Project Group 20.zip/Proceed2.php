<html>
<body>
<h2>It doesn't seem like your family member may need a check-up yet ! <br>
<br>Let us know if any severe complications arise in the future
,  in any case, it is always better to be safe than sorry. Kindly follow the precautions below and save yourself
<br> and your family from the novel Covid-19 </h2><br>
<h2> Precautions : </h2>
<h3>->Wash hands frequently with soap or an alcohol based rub for frequently and each time for atleast 20 seconds<br>
->Avoid crowded places and strictly maintain social distancing <br>
-> Make the affected person wear a mask<br>
-> Make the person wash hands frequently and avoid touching surfaces<br>
-> Practice respiratory hygiene<br>
</h3><br><br>
<h2> You may expect the check-up of your sick family member soon ..... </h2>
</body>
</html>